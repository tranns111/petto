import { Client, Databases, Storage, ID, Query } from "node-appwrite";

export default async ({ req, res }) => {
  const { email, pet_id } = JSON.parse(req.body || "{}");

  if (!email || !pet_id) {
    return res.json({ error: "Missing fields" }, 400);
  }

  const client = new Client()
    .setEndpoint(process.env.APPWRITE_ENDPOINT)
    .setProject(process.env.APPWRITE_PROJECT_ID)
    .setKey(process.env.APPWRITE_API_KEY);

  const databases = new Databases(client);
  const storage = new Storage(client);

  // One submission per email
  const existing = await databases.listDocuments(
    "petsDB",
    "submissions",
    [Query.equal("email", email)]
  );

  if (existing.total > 0) {
    return res.json({ error: "Email already used" }, 409);
  }

  // Save to database
  await databases.createDocument(
    "petsDB",
    "submissions",
    ID.unique(),
    { email, pet_id }
  );

  // Save as .txt file
  const content = `EMAIL: ${email}\nPET ID: ${pet_id}\n`;
  const file = new Blob([content], { type: "text/plain" });

  await storage.createFile(
    "pet-texts",
    ID.unique(),
    file
  );

  return res.json({ success: true });
};
